﻿
Partial Class Oferta
    Inherits System.Web.UI.Page

End Class

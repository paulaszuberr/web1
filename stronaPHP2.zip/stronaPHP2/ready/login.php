

<?php  session_start(); ?>  

<?php
// session starts with the help of this function up^
if(isset($_SESSION['use']))   // Checking whether the session is already there or not if 
                              // true then header redirect it to the home page directly 
 {
    header("Location:home.php"); 
 }

if(isset($_POST['login']))   // it checks whether the user clicked login button or not 
{
     $user = $_POST['user'];
     $pass = $_POST['pass'];

      if($user == "ola" && $pass == "1234")  // username is  set to "ola"  and Password   
         {                                   // is 1234 by default     

          $_SESSION['use']=$user;


         echo '<script type="text/javascript"> window.open("home.php","_self");</script>';            //  On Successful Login redirects to home.php

        }

        else
        {
            echo "niepoprawne dane";        
        }
}
 ?>
<html>
<head>

<title> Login</title>

</head>

<body>

<form action="" method="post">

    <table width="200" border="0">
  <tr>
    <td>  Nazwa</td>
    <td> <input type="text" name="user" > </td>
  </tr>
  <tr>
    <td> Haslo  </td>
    <td><input type="password" name="pass"></td>
  </tr>
  <tr>
    <td> <input type="submit" name="login" value="LOGIN"></td>
    <td></td>
  </tr>
</table>
</form>

</body>
</html>
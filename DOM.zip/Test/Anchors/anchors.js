function numberFun() {
    var x = document.anchors.length;
    document.getElementById("no").innerHTML = x;
}

function htmlFirstFun() {
    var x = document.anchors[0].innerHTML;
    document.getElementById("demo").innerHTML = x;
}